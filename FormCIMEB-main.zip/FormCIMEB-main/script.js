btnCad = document.querySelector('#cadastro');
btnConsulta = document.querySelector("#consulta");

function cadastroBtn() {
 btnConsulta.classList.add("d-none");
 btnCad.classList.remove("d-none");

}
function consultaBtn() {
 btnCad.classList.add("d-none");
 btnConsulta.classList.remove("d-none");
}